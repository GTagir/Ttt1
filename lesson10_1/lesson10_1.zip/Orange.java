package lesson10_1;

public class Orange extends Fruit{
    @Override
    public double getWeight() {
        return 1.5;
    }
}
