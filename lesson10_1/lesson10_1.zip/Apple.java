package lesson10_1;

public class Apple extends Fruit{
    @Override
    public double getWeight() {
        return 1.0;
    }
}
