package lesson10_1;

public class GoldenApple extends Apple{
}
