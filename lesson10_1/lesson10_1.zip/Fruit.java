package lesson10_1;

public abstract class Fruit {
    public abstract double getWeight();
}
