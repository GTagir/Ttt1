package lesson8;

public interface Participant { //Участник
    String getName();
    int getRun();
    int getJump();
}
