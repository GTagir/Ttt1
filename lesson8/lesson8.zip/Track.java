package lesson8;

public interface Track {
    boolean overcome(Participant participant);
}
