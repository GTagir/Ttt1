package lesson9;

public class MyArraySizeException extends Exception{
    public MyArraySizeException(String text) {
        super(text);
    }
}
