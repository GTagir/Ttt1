package lesson9;

public class MyArrayDataException extends Exception{
    public MyArrayDataException(String text) {
        super(text);
    }
}
